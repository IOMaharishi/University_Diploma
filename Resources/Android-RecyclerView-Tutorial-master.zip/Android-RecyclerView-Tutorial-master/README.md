# Android-RecyclerView-Tutorial
Android RecyclerView Tutorial made with material design
![alt tag](http://www.androidsources.com/wp-content/uploads/2015/08/recyclerview.png "Android RecyclerView Tutorial made with material design")
